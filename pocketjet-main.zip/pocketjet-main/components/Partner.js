'use client';
import { useState, useEffect } from 'react';
import { db } from '@/firebase/firebaseConfig';
import { collection, getDocs } from 'firebase/firestore';

export default function PartnersModal() {
  const [partners, setPartners] = useState([]);
  const [selectedPartner, setSelectedPartner] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchPartners = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, 'partners'));
        const partnersData = [];
        querySnapshot.forEach((doc) => {
          if (doc.data().active) {
            partnersData.push({ id: doc.id, ...doc.data() });
          }
        });
        setPartners(partnersData);
      } catch (error) {
        console.error("Error fetching partners:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchPartners();
  }, []);

  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      {/* Partner Buttons Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mb-2">
        {partners.map((partner) => (
          <button
            key={partner.id}
            onClick={() => setSelectedPartner(partner)}
            className="bg-slate-800 hover:bg-slate-700 rounded-lg p-4 flex flex-col items-center transition-all"
          >
            <img 
              src={partner.logoUrl} 
              alt={partner.name} 
              className="h-12 w-auto mb-2 object-contain"
            />
            <span className="text-white font-medium">{partner.name}</span>
          </button>
        ))}
      </div>

      {/* Modal for iframe */}
      {selectedPartner && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
          <div className="bg-slate-900 rounded-xl w-full max-w-6xl max-h-[90vh] flex flex-col">
            <div className="flex justify-between items-center p-3 border-b border-slate-700">
              <h3 className="text-xl font-bold text-white">
                {selectedPartner.name} Offers
              </h3>
              <button 
                onClick={() => setSelectedPartner(null)}
                className="text-gray-400 hover:text-white text-3xl"
              >
                ✕
              </button>
            </div>
            <div className="flex-1 overflow-hidden">
              <iframe
                sandbox="allow-popups allow-same-origin allow-scripts allow-top-navigation-by-user-activation allow-popups-to-escape-sandbox"
                src={selectedPartner.iframeUrl}
                className="w-full h-[80vh] border-0 bg-transparent"
                frameBorder="0"
                title={`${selectedPartner.name} Offers`}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}