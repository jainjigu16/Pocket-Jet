'use client';
import { createContext, useContext, useEffect, useState } from 'react';
import { db, auth } from '@/firebase/firebaseConfig';
import { doc, getDoc, setDoc, updateDoc, increment, collection, query, where, getDocs, writeBatch, serverTimestamp } from 'firebase/firestore';
import { signInWithCustomToken } from 'firebase/auth';
import { usePathname, useRouter } from 'next/navigation';
import { toast } from 'react-hot-toast';
import Script from 'next/script';

const TelegramContext = createContext();

export const TelegramProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const pathname = usePathname();

  const generateReferralCode = () => {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  };

  const handleReferral = async (userId, userReferralCode) => {
    try {
      const tg = window.Telegram?.WebApp;
      if (!tg) return;
      
      const refCode = tg.initDataUnsafe?.start_param || 
                     new URLSearchParams(window.location.search).get('startapp') || 
                     new URLSearchParams(window.location.search).get('ref');
      
      if (!refCode || refCode === userReferralCode) return;

      const userDoc = await getDoc(doc(db, 'users', userId));
      if (!userDoc.exists()) throw new Error('User document not found');
      if (userDoc.data().referredBy) return;

      const referrerQuery = query(
        collection(db, 'users'),
        where('referralCode', '==', refCode)
      );
      const referrerSnapshot = await getDocs(referrerQuery);

      if (referrerSnapshot.empty) throw new Error('Referrer not found');

      const referrerId = referrerSnapshot.docs[0].id;
      const batch = writeBatch(db);
      const timestamp = serverTimestamp();
      
      batch.set(doc(db, 'referrals', `${referrerId}_${userId}`), {
        referrerId,
        refereeId: userId,
        createdAt: timestamp,
        rewardGiven: false
      });

      batch.update(doc(db, 'users', userId), {
        referredBy: refCode,
        lastUpdated: timestamp
      });

      batch.update(doc(db, 'users', referrerId), {
        coins: increment(10),
        lastUpdated: timestamp
      });

      await batch.commit();
      window.history.replaceState({}, document.title, window.location.pathname);
      toast.success('Referral bonus applied!');
    } catch (error) {
      console.error('Referral error:', error);
      toast.error(error.message || 'Referral failed');
    }
  };

const authenticateWithBackend = async (tgUser) => {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/auth`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        user: tgUser
      })
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Authentication failed');

    // Sign in with the custom token
    const userCredential = await signInWithCustomToken(auth, data.token);
    return userCredential.user.uid;
  } catch (error) {
    console.error('Authentication error:', error);
    throw error;
  }
};

 useEffect(() => {
    const initTelegramApp = async () => {
      try {
        // Wait for Telegram script to load
        if (!window.Telegram?.WebApp?.initDataUnsafe?.user) {
          throw new Error('Telegram user data not available');
        }

        const tg = window.Telegram.WebApp;
        const tgUser = tg.initDataUnsafe.user;
        
        // Authenticate with backend
        const uid = await authenticateWithBackend(tgUser);
        
        const userRef = doc(db, 'users', uid);
        const userSnap = await getDoc(userRef);
        const timestamp = serverTimestamp();

        if (!userSnap.exists()) {
          await setDoc(userRef, {
            userId: uid,
            first_name: tgUser.first_name,
            username: tgUser.username || '',
            coins: 10,
            referralCode: generateReferralCode(),
            createdAt: timestamp,
            lastUpdated: timestamp
          });
        }

        setUser({
          ...tgUser,
          uid,
          ...(userSnap.exists() ? userSnap.data() : {
            coins: 100,
            referralCode: generateReferralCode()
          })
        });
await handleReferral(uid, userSnap.data()?.referralCode || '');

tg.expand();
tg.enableClosingConfirmation();

  } catch (error) {
        console.error('Initialization failed:', error);
        if (pathname !== '/') {
          router.replace('/');
        }
      } finally {
        setLoading(false);
      }
    };

    if (window.Telegram?.WebApp) {
      initTelegramApp();
    } else {
      setLoading(false);
      if (pathname !== '/') {
        router.replace('/');
      }
    }
  }, [pathname, router]);

  useEffect(() => {
    if (!loading && !user && pathname !== '/') {
      router.replace('/');
    }
  }, [loading, user, pathname, router]);
 
  if (loading) {
    return (
      <>
        <Script 
          src="https://telegram.org/js/telegram-web-app.js" 
          strategy="beforeInteractive"
          onError={() => setLoading(false)}
        />
        <div className="touch-pan-y select-none min-h-screen overflow-x-hidden max-w-[100%] bg-gray-900 text-white flex flex-col items-center">
          <div className="text-center w-full"> 
            <div className="w-full mt-[15%] bg-[url('https://cdn.glitch.global/f6df49f0-db22-4165-93b0-d2ef7cf19209/20250602_1928_Midcentury%20Podcast%20Scene_remix_01jwrew5z8f9jbzp9rzvgnmfg1.png')] bg-cover bg-center h-[60vh] relative rounded-3xl shadow-lg">
            </div>
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500 mx-auto mb-4 mt-4"></div>
            <p className="mb-1 mt-1">Please Wait trying to Login ..</p>
            <h1 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-blue-500">
              PocketJet 
            </h1>
          </div>
        </div>
      </>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex flex-col items-center justify-center p-4">
  <div className="w-[90%] mt-[5%] bg-[url('https://cdn.glitch.global/f6df49f0-db22-4165-93b0-d2ef7cf19209/20250602_1928_Midcentury%20Podcast%20Scene_remix_01jwrew5z8f9jbzp9rzvgnmfg1.png')] bg-cover bg-center h-[60vh] relative rounded-3xl shadow-lg">
  </div>
        <h1 className="text-2xl font-bold mb-4">.........</h1>
        <p className="mb-6">Please open this app through Telegram</p>
        <a
          href="https://t.me/pocketjetbot/app?startapp=X7M8TW"
          className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg"
        >
          Open in Telegram
        </a>
      </div>
    );
  }

  return (
    <>
      <Script 
        src="https://telegram.org/js/telegram-web-app.js" 
        strategy="beforeInteractive"
      />
      <TelegramContext.Provider value={{ user, loading }}>
        {children}
      </TelegramContext.Provider>
    </>
  );
};

export const useTelegramUser = () => {
  const context = useContext(TelegramContext);
  if (context === undefined) {
    throw new Error('useTelegramUser must be used within a TelegramProvider');
  }
  return context;
};
