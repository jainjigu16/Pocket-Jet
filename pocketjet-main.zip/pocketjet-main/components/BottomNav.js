'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useState, useEffect } from 'react'

const navItems = [
  { 
    label: 'Home', 
    icon: '🏠',  // Galaxy - for discovery
    href: '/home' 
  },
  { 
    label: 'Earn', 
    icon: '🚀',  // Rocket - main earning action
    href: '/earn' 
  },
  { 
    label: 'Team', 
    icon: '🤝',  // Rocket - main earning action
    href: '/team' 
  },
  { 
    label: 'Me', 
    icon: '👨‍🚀', // Astronaut - for profile
    href: '/profile' 
  }
]

export default function Web3Nav() {
  const pathname = usePathname()
  const [activeGlow, setActiveGlow] = useState('')

  useEffect(() => {
    const item = navItems.find(item => pathname.startsWith(item.href))
    setActiveGlow(item ? item.label : '')
  }, [pathname])

  return (
    <nav className="fixed bottom-7 inset-x-0 mx-auto w-[88%] border-t h-[8%] border-gray-200 rounded-2xl max-w-md z-50 bg-opacity-25">
      <div className="relative">
        {/* Animated background glow */}
        <div className={`absolute inset-0 bg-gray-600/20 blur-xl rounded-2xl transition-all duration-500 ${
          activeGlow ? 'opacity-100' : 'opacity-0'
        }`}></div>
        
        {/* Navigation container */}
        <div className="relative bg-gray-900/80 backdrop-blur-lg border-t-gray-700/50 rounded-2xl p-3 shadow-lg">
          <div className="flex justify-around">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`flex flex-col items-center justify-center w-full transition-all duration-300 ${
                  pathname.startsWith(item.href) 
                    ? 'text-purple-400 scale-110' 
                    : 'text-gray-400 hover:text-gray-200 hover:scale-105'
                }`}
                onMouseEnter={() => setActiveGlow(item.label)}
                onMouseLeave={() => {
                  const currentItem = navItems.find(i => pathname.startsWith(i.href))
                  setActiveGlow(currentItem ? currentItem.label : '')
                }}
              >
                <div className={`text-3xl mb-1 transition-transform duration-300 ${
                  pathname.startsWith(item.href) ? 'animate-bounce' : ''
                }`}>
                  {item.icon}
                </div>
                <span className="text-xl font-bold tracking-tight">
                  {item.label}
                </span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </nav>
  )
}
