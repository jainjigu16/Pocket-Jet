'use client';
import { Send, Instagram, MessageSquare, HelpCircle,Copy,Whatsapp } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { FaWhatsapp  } from 'react-icons/fa';
export default function ShareReferral({ referralCode }) {
  if (!referralCode) return null;

  const referralLink = `https://t.me/pocketjetbot/app?startapp=${referralCode}`;
  const message = `Hello👋 You Want to Make real Money 🤑? Join This Earned 100 Coins And More Click On Below This Link \n\n🔗 ${referralLink}`;

  const handleShare = (platform) => {
    try {
      switch(platform) {
        case 'whatsapp':
          window.open(`https://wa.me/?text=${encodeURIComponent(message)}`);
          break;
        case 'telegram':
          window.open(`https://t.me/share/url?url=&text=${encodeURIComponent(message)}`);
          break;
        case 'instagram':
        case 'copy':
          navigator.clipboard.writeText(message);
          toast.success('Link copied 🤑👋!');
          break;
      }
    } catch (error) {
      toast.error('Failed to share');
      console.error('Sharing error:', error);
    }
  };

  return (
      <div className="flex justify-around">
            <a 
              onClick={() => handleShare('telegram')}
              target="_blank"
              className="bg-sky-600 hover:bg-sky-900 p-3 rounded-full transition"
            >
              <Send size={24} />
            </a>
            <a 
              onClick={() => handleShare('instagram')}
              target="_blank"
              className="bg-gradient-to-tr from-purple-600 to-pink-600 hover:opacity-90 p-3 rounded-full transition"
            >
              <Instagram size={24} />
            </a>
            <a 
              onClick={() => handleShare('whatsapp')}
              target="_blank"
              className="bg-green-500 hover:bg-green-600 p-3 rounded-full transition"
            >
              <FaWhatsapp size={24} />
            </a>
            <a 
              onClick={() => handleShare('copy')}
              className="bg-gray-700 hover:bg-gray-600 p-3 rounded-full transition"
            >
              <MessageSquare size={24} />
            </a>
          </div>
  );
}