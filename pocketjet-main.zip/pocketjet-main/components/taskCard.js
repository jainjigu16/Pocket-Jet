// // 'use client';
// // import { db } from '../firebase/firebaseConfig';
// // import { doc, updateDoc, getDoc } from 'firebase/firestore';
// // import { useState } from 'react';

// // export default function TaskCard({ task }) {
// //   const [completed, setCompleted] = useState(false);
// //   const [loading, setLoading] = useState(false);

// //   const userId = typeof window !== 'undefined' && window?.Telegram?.WebApp?.initDataUnsafe?.user?.id;

// //   const handleCompleteTask = async () => {
// //     if (!userId) return alert('User not authenticated.');

// //     setLoading(true);

// //     try {
// //       const userRef = doc(db, 'users', userId.toString());
// //       const userSnap = await getDoc(userRef);

// //       if (userSnap.exists()) {
// //         const currentCoins = userSnap.data().coins || 0;
// //         const reward = task.reward || 1;

// //         await updateDoc(userRef, {
// //           coins: currentCoins + reward,
// //         });

// //         setCompleted(true);
// //       }
// //     } catch (error) {
// //       console.error('Error completing task:', error);
// //       alert('Something went wrong.');
// //     }

// //     setLoading(false);
// //   };

// //   return (
// //     <div className="bg-white shadow-md p-4 mb-3 rounded-lg border border-gray-200">
// //       <div className="flex justify-between items-center">
// //         <div>
// //           <h3 className="font-semibold text-base">{task.title}</h3>
// //           <p className="text-sm text-gray-600">{task.description}</p>
// //           <p className="text-green-600 mt-1">Reward: {task.reward} 💰</p>
// //         </div>

// //         <button
// //           onClick={handleCompleteTask}
// //           disabled={completed || loading}
// //           className={`ml-4 px-4 py-1 text-sm rounded-md ${
// //             completed
// //               ? 'bg-gray-400 cursor-not-allowed'
// //               : 'bg-blue-500 text-white hover:bg-blue-600'
// //           }`}
// //         >
// //           {completed ? 'Completed' : loading ? '...' : 'Complete'}
// //         </button>
// //       </div>
// //     </div>
// //   );
// // }


// 'use client';
// import { db } from '../firebase/firebaseConfig';
// import { doc, getDoc } from 'firebase/firestore';
// import { useState, useEffect } from 'react';

// export default function TaskCard({ task }) {
//   const [completed, setCompleted] = useState(false);
//   const [loading, setLoading] = useState(true);

//   const userId = typeof window !== 'undefined' && window?.Telegram?.WebApp?.initDataUnsafe?.user?.id;

//   useEffect(() => {
//     const checkCompletion = async () => {
//       if (!userId) return setLoading(false);
//       try {
//         const userRef = doc(db, 'users', userId.toString());
//         const userSnap = await getDoc(userRef);
//         if (userSnap.exists()) {
//           const completedTasks = userSnap.data().completedTasks || [];
//           if (completedTasks.includes(task.taskCode)) {
//             setCompleted(true);
//           }
//         }
//       } catch (error) {
//         console.error('Error checking task completion:', error);
//       }
//       setLoading(false);
//     };
//     checkCompletion();
//   }, [userId, task.taskCode]);

//   if (loading) {
//     return (
//       <div className="bg-gray-900 shadow-md p-4 mb-3 rounded-lg border border-gray-200 animate-pulse gap-4">
//         <div className="h-4 bg-gray-300 rounded w-1/2 mb-2"></div>
//         <div className="h-3 bg-gray-300 rounded w-3/4 mb-2"></div>
//         <div className="h-3 bg-gray-300 rounded w-1/3 mb-4"></div>
//         <div className="h-8 bg-gray-300 rounded w-24"></div>
//       </div>
//     );
//   }

//   return (
//     <div className="bg-black shadow-md p-4 mb-3 rounded-lg border border-gray-900 px-4 py-4">
//       <div className="flex justify-between items-center">
//         <div className="cursor-default">
//           <h3 className="font-semibold text-base text-white">{task.title}</h3>
//           <p className="text-sm text-white">{task.description}</p>
//           <p className="text-green-600 mt-1">Reward: {task.reward} 💰</p>
//         </div>

//         {completed ? (
//           <div
//             className="ml-4 px-4 py-1 text-sm rounded-md bg-gradient-to-r from-green-400 to-green-600 text-white shadow-lg animate-pulse"
//           >
//             Completed
//           </div>
//         ) : (
//           <a
//             href={task.link}
//             target="_blank"
//             rel="noopener noreferrer"
//             className="ml-4 px-4 py-1 text-sm rounded-md bg-blue-500 text-white hover:bg-blue-600"
//           >
//             Start
//           </a>
//         )}
//       </div>
//     </div>
//   );
// }

'use client';
import { useState, useEffect } from 'react';
import { db } from '../firebase/firebaseConfig';
import { doc, getDoc } from 'firebase/firestore';
import { isTelegramUser } from '../lib/auth';

export default function TaskCard({ task }) {
  const [isCompleted, setIsCompleted] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    const checkCompletion = async () => {
      const user = isTelegramUser();
      if (!user) return;

      const docRef = doc(db, 'users', user.id.toString());
      const userSnap = await getDoc(docRef);
      if (userSnap.exists()) {
        const data = userSnap.data();
        if (data.activity && data.activity.some((item) => item.includes(task.title))) {
          setIsCompleted(true);
        }
      }
      setLoading(false);
    };
    checkCompletion();
  }, [task]);
  
  if (loading) {
    return (
      <div className="bg-gray-900 shadow-md p-4 mb-3 rounded-lg border border-gray-200 animate-pulse gap-4">
        <div className="h-4 bg-gray-300 rounded w-1/2 mb-2"></div>
        <div className="h-3 bg-gray-300 rounded w-3/4 mb-2"></div>
        <div className="h-3 bg-gray-300 rounded w-1/3 mb-4"></div>
        <div className="h-8 bg-gray-300 rounded w-24"></div>
      </div>
    );
  }
  return (
    <div 
      className={`relative overflow-hidden rounded-2xl p-3 w-[85%] mx-auto border border-gray-700 transition-all duration-300 ${
        isCompleted 
          ? 'bg-gradient-to-br from-green-900/20 to-green-800/30' 
          : 'bg-gradient-to-br from-gray-800 to-gray-900 hover:from-gray-700 hover:to-gray-800'
      } ${isHovered ? 'shadow-lg' : 'shadow-md'}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Glow effect */}
      <div className={`absolute inset-0 bg-gradient-to-r from-purple-500/10 to-blue-500/10 rounded-2xl transition-opacity duration-300 ${
        isHovered ? 'opacity-100' : 'opacity-0'
      }`}></div>

      {/* Task content */}
      <div className="relative z-10 align-middle text-center">
        <h3 className="text-lg font-bold text-white mb-2 truncate">{task.title}</h3>
        <div className="flex items-center justify-center gap-2 mb-4">{task.description}
          <span className="text-yellow-400 text-xl">🪙</span>
          <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-amber-400 to-yellow-500">
            +{task.reward}
          </span>
          <span className="text-gray-400 text-sm">coins</span>
        </div>

        {isCompleted ? (
          <button
            className="w-full py-5 rounded-xl bg-gradient-to-r from-green-600 to-emerald-600 text-white font-bold shadow-lg shadow-green-500/20 flex items-center justify-center gap-2"
            disabled>
            <span className="text-xl">✅</span>
            <span>Completed</span>
          </button>
        ) : (
          <a
            href={task.link}
            target="_blank"
            rel="noopener noreferrer"
            className={`w-full py-5 text-center rounded-xl font-bold flex items-center justify-center gap-2 transition-all duration-300 ${
              isHovered
                ? 'bg-gradient-to-r from-purple-600 to-blue-600 shadow-lg shadow-purple-500/30'
                : 'bg-gradient-to-r from-purple-700 to-blue-700 shadow-md'
            }`}
          >
            <span className="text-xl animate-bounce">🚀</span>
            <span>Start Earning</span>
          </a>
        )}
      </div>

      {/* Completed badge */}
      {isCompleted && (
        <div className="absolute top-3 right-3 bg-green-900/80 text-green-300 text-xs px-2 py-1 rounded-full flex items-center">
          <span className="w-2 h-2 bg-green-400 rounded-full mr-1 animate-pulse"></span>
          Verified
        </div>
      )}
    </div>
  );
}