'use client';
import { useState } from 'react';
import { MessageSquare, Send, Shield, X } from 'lucide-react';

export default function SupportAndPrivacy() {
  const [showModal, setShowModal] = useState(false);
  const [activeTab, setActiveTab] = useState('support'); // 'support' or 'privacy'

  const openTelegramSupport = () => {
    window.open('https://t.me/pocketjet_official', '_blank');
  };

  const openWhatsAppSupport = () => {
    window.open('https://whatsapp.com/channel/0029VbAuIHC2kNFwVKsNfK1c', '_blank');
  };

  return (
    <>
      {/* Trigger Button */}
      <button  onClick={() => setShowModal(true)} className="fixed top-[80%] bg-[url('https://cdn.glitch.global/8ab086b1-c2f5-472b-9271-6d5d0fa4f9e8/chat.png')] bg-center bg-no-repeat bg-cover w-12 h-15 left-1 animate-bounce overflow-auto">.</button>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-xl w-full max-w-md border border-gray-700">
            {/* Modal Header */}
            <div className="flex justify-between items-center p-4 border-b border-gray-700">
              <div className="flex gap-4">
                <button
                  onClick={() => setActiveTab('support')}
                  className={`px-4 py-2 rounded-lg ${activeTab === 'support' ? 'bg-blue-600 text-white' : 'text-gray-400'}`}
                >
                  Customer Support
                </button>
                <button
                  onClick={() => setActiveTab('privacy')}
                  className={`px-4 py-2 rounded-lg ${activeTab === 'privacy' ? 'bg-blue-600 text-white' : 'text-gray-400'}`}
                >
                  Privacy Policy
                </button>
              </div>
              <button 
                onClick={() => setShowModal(false)}
                className="text-gray-400 hover:text-white p-2"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 max-h-[70vh] overflow-y-auto">
              {activeTab === 'support' ? (
                <div className="space-y-6">
                  <h3 className="text-xl font-bold">Contact Support</h3>
                  <p>Get help with your account or report issues</p>
                  
                  <div className="space-y-4">
                    <button
                      onClick={openTelegramSupport}
                      className="w-full flex items-center gap-3 bg-blue-600 hover:bg-blue-500 text-white p-4 rounded-xl transition"
                    >
                      <Send size={20} />
                      <div className="text-left">
                        <p className="font-bold">Telegram Support</p>
                        <p className="text-sm text-blue-100">24/7 live chat 🤗</p>
                      </div>
                    </button>

                    <button
                      onClick={openWhatsAppSupport}
                      className="w-full flex items-center gap-3 bg-green-600 hover:bg-green-500 text-white p-4 rounded-xl transition"
                    >
                      <MessageSquare size={20} />
                      <div className="text-left">
                        <p className="font-bold">WhatsApp Support </p>
                        <p className="text-sm text-green-100">Quick responses 🤝</p>
                      </div>
                    </button>
                  </div>

                  <div className="bg-gray-700 p-4 rounded-lg">
                    <h4 className="font-bold mb-2">Support Hours 🚀</h4>
                    <p className="text-sm">Monday - Friday: 9AM - 6PM (UTC)</p>
                    <p className="text-sm">Weekends: Limited availability 💬</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <h3 className="text-xl font-bold">Privacy Policy</h3>
                  <div className="space-y-3 text-sm">
                    <p>Last Updated: {new Date().toLocaleDateString()}</p>
                    
                    <h4 className="font-bold mt-4">1. Information We Collect</h4>
                    <p>We collect basic user data provided through Telegram authentication including your user ID, first name, and username.</p>
                    
                    <h4 className="font-bold mt-4">2. How We Use Your Data</h4>
                    <p>Your data is used solely for account management and service personalization. We never sell your information to third parties.</p>
                    
                    <h4 className="font-bold mt-4">3. Data Security</h4>
                    <p>We implement industry-standard security measures to protect your information from unauthorized access.</p>
                    
                    <h4 className="font-bold mt-4">4. Third-Party Services</h4>
                    <p>We use Eth for data storage and authentication. Their privacy policies apply to their services.</p>
                    
                    <h4 className="font-bold mt-4">5. Your Rights</h4>
                    <p>You may request account deletion at any time by contacting our support team.</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}