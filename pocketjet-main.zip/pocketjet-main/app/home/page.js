'use client';
import {useTelegramUser} from "../../components/Taps";
import { useEffect, useState } from 'react';
import { db } from '../../firebase/firebaseConfig';
import { collection, getDocs, doc, getDoc } from 'firebase/firestore';
import BottomNav from '../../components/BottomNav';
import TaskCard from '../../components/taskCard';
import { isTelegramUser } from '../../lib/auth';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay, Pagination } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/pagination';


//video popup 
const VideoPopup = ({ videoUrl, onClose }) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4">
      <div className="relative w-full max-w-2xl">
        <button 
          onClick={onClose}
          className="absolute -top-10 right-0 text-white hover:text-gray-300"
        >
          ✕ Close
        </button>
        <div className="aspect-w-16 aspect-h-9 w-full">
          <video 
            controls 
            controlsList="nodownload noremoteplayback"
            disablePictureInPicture
            autoPlay 
            className="w-full rounded-lg"
            src={videoUrl}
          />
        </div>
      </div>
    </div>
  );
};

export default function HomePage() {
 
  const [showVideo, setShowVideo] = useState(false);
  const [videoUrl, setVideoUrl] = useState(''); 
  const [user, setUser] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [coin, setCoin] = useState(0);


  useEffect(() => {
    const tgUser = isTelegramUser();
    if (tgUser) {
      setUser(tgUser);
      fetchUserData(tgUser.id);
      fetchTasks();
      if (window.Telegram?.WebApp?.expand) {
        window.Telegram.WebApp.requestFullscreen();
      }
    }

    // Countdown timer simulation
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        const [h, m] = prev.split('h ').map(part => parseInt(part));
        if (m > 0) return `${h}h ${m - 1}m`;
        if (h > 0) return `${h - 1}h 59m`;
        return 'Claim now!';
      });
    }, 60000);

    return () => clearInterval(timer);
  }, []);

  const fetchUserData = async (uid) => {
    const docRef = doc(db, 'users', uid.toString());
    const userSnap = await getDoc(docRef);
    if (userSnap.exists()) {
      setCoin(userSnap.data().coins || 0);
    }
  };

  const fetchTasks = async () => {
    const querySnapshot = await getDocs(collection(db, 'tasks'));
    const taskList = [];
    querySnapshot.forEach((doc) => {
      taskList.push({ id: doc.id, ...doc.data() });
    });
    setTasks(taskList);
  };

  return (
    <div className="min-h-screen bg-gray-950 text-white pt-2 w-full">

<div className="p-0 m-0 flex items-center justify-between px-4 py-4 mt-4 relative left-[5%] top-13 w-[90%] h-13 bg-transparent z-50"> {/* Added mt-4 for top margin */}
    <div className="flex items-center gap-3"> {/* Removed pt-10 here - control spacing from parent */}
        {user?.photo_url && (
        <div className="relative">
            <img
            src={user.photo_url}
            alt="profile"
            className="w-12 h-12 rounded-full border-2 border-purple-600/80 object-cover" />
            <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-green-500 rounded-full border-2 border-gray-950"></div>
        </div>
        )}
        <div>
        <p className="text-sm text-gray-400">Welcome,</p>
        <p className="font-bold text-white">{user?.first_name}</p>
        </div>
    </div>
    <div className="flex items-center gap-2 bg-gray-900/80 px-3 py-1.5 rounded-full backdrop-blur-sm"> {/* Added transparency and blur */}
        <span className="font-bold text-white">{coin}</span>
        <span className="text-yellow-400">🪙</span>
    </div>
</div>
      {/* Premium Banner Section */}
   <div className="w-full relative group">
        <Swiper
          modules={[Autoplay, Pagination]}
          spaceBetween={16}
          slidesPerView={1.15}
          centeredSlides={true}
          autoplay={{ delay: 3500, disableOnInteraction: false }}
          pagination={{ 
            clickable: true,
            bulletClass: 'swiper-pagination-bullet bg-gray-600',
            bulletActiveClass: 'swiper-pagination-bullet-active !bg-purple-500'
          }}
          className="w-full h-[21vh] md:h-[21vh] overflow-hidden mt-[16%]"//"h-[150px] w-full mt-10"
        >
          <SwiperSlide className="bg-gradient-to-br from-purple-700/90 to-indigo-700/90 p-5 rounded-2xl relative overflow-hidden">
            <div className="absolute -right-5 -bottom-6 text-8xl opacity-20">🚀</div>
            <div className="relative z-10 h-[80%] flex flex-col justify-between">
              <div className='relative z-10 top-2 left-3 h-30'>
                <h3 className="text-xl font-bold mb-1">2X Earnings 🤑</h3>
                <p className="text-gray-100 text-sm">Your {tasks.length} tasks today</p>
                <p className="text-gray-100 text-sm">watch Video Tutorial</p>
              </div>
              <div className='justify-center text-center pt-5'>
              <button 
              onClick={() => {
                setVideoUrl('https://cdn.glitch.global/f6df49f0-db22-4165-93b0-d2ef7cf19209/1.mp4'); // Set your video URL
                setShowVideo(true);
              }}
              className="h-10 w-[90%] bg-white/10 backdrop-blur-sm py-0 rounded-xl text-sm font-medium border border-white/20 hover:bg-white/20 transition justify-end-safe flex-col"
            >
              Watch Video Tutorial⚡
            </button>
              </div>
            </div>
          </SwiperSlide>
  
          <SwiperSlide className="bg-[url('https://cdn.glitch.me/f6df49f0-db22-4165-93b0-d2ef7cf19209/s1.gif')] bg-cover bg-no-repeat p-5 rounded-2xl relative overflow-hidden">
            <div className="absolute -right-6 -bottom-6 text-8xl opacity-15">💎</div>
            <div className="relative z-10 h-[80%] flex flex-col justify-between">
      
              <div className='justify-center pt-[35%] text-center'>
              <button onClick={() => {
                setVideoUrl('https://cdn.glitch.global/f6df49f0-db22-4165-93b0-d2ef7cf19209/2.mp4'); // Set your video URL
                setShowVideo(true);
              }} className="h-10 w-[40%] bg-white/10 backdrop-blur-sm py-0 rounded-xl text-sm font-medium border border-black hover:bg-white/20 transition justify-items-start flex-col">
                Refer Now 🤝
              </button> 
               </div>
            </div>
          </SwiperSlide>
          <SwiperSlide className="bg-gradient-to-br from-amber-600/90 to-pink-600/90 p-5 rounded-2xl relative overflow-hidden">
            <div className="absolute -right-6 -bottom-6 text-8xl opacity-15">💎</div>
            <div className="relative z-10 h-[80%] flex flex-col justify-between">
              <div className='relative z-10 top-3 left-3 h-30'>
                <h3 className="text-xl font-bold mb-2">WhatsApp Status Task</h3>
                <p className="text-gray-300 text-sm">You Can Earn By Whatsapp Status</p>
                <p className="text-gray-300 text-sm">Boost Pocket By pocketjetbot</p>
              </div>
              <div className='relative z-10 top-3 left-5 flex-row-reverse pr-2'>
              <button className="h-10 w-[90%] bg-white/10 backdrop-blur-sm py-0 rounded-xl text-sm font-medium border border-white/20 hover:bg-white/20 transition justify-end-safe flex-col">
                Avalible Soon 💰
              </button>
              </div>
            </div>
          </SwiperSlide>
              <SwiperSlide className="bg-[url('https://cdn.glitch.me/f6df49f0-db22-4165-93b0-d2ef7cf19209/s2.gif')] bg-cover bg-no-repeat p-5 rounded-2xl relative overflow-hidden">
            <div className="absolute -right-6 -bottom-6 text-8xl opacity-15">💎</div>
            <div className="relative z-10 h-[80%] flex flex-col justify-between">
            
              <div className='justify-center pl-[35%] pt-[35%] text-center'>
              <button onClick={() => {
                setVideoUrl('https://cdn.glitch.global/f6df49f0-db22-4165-93b0-d2ef7cf19209/3.mp3'); // Set your video URL
                setShowVideo(true);
              }} className="h-10 w-[66%] bg-white/10 backdrop-blur-sm py-0 rounded-xl text-sm font-medium border border-white/20 hover:bg-white/20 transition justify-items-start flex-col">
                Join Community 💬
              </button> 
               </div>
            </div>
          </SwiperSlide>
        </Swiper>
      </div>  

      {/* Tasks Section */}
      <div className="align-middle w-full content-center-safe mt-0 h-140">
        <div className="w-[95%] h-10">
          <h2 className="text-lg font-bold">&nbsp; &nbsp; &nbsp; &nbsp;🚀Available Tasks <span className="text-sm bg-gray-900 rounded float-end">{tasks.length}&nbsp; Available</span></h2> 
        </div>
        <div className="w-full h-120 overflow-scroll overflow-x-hidden scroll-m-0.5 mt-0.5">
        <div className="grid grid-cols-1 gap-3 w-[100%] rounded-2xl text-center pb-[12%]">
          {tasks.length > 0 ? (
            tasks.map((task) => (
              <TaskCard key={task.id} task={task} />
            ))
          ) : (
            <div className="text-center py-6">
              <p className="text-gray-500 mb-3">No tasks available currently</p>
              <button 
                className="bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded-full text-sm font-medium transition"
                onClick={fetchTasks}
              >
                Refresh Tasks
              </button>
            </div>
          )} 
        </div>
        </div>
      </div>

       {showVideo && (
        <VideoPopup 
          videoUrl={videoUrl} 
          onClose={() => setShowVideo(false)} 
        />
      )}
  
      <BottomNav />
  
    </div>
  );
}
