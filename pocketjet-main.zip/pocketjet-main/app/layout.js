// app/layout.js
import { Sora, IBM_Plex_Mono } from 'next/font/google';
import './globals.css';
import { TelegramProvider } from '@/components/Taps';
// Modern Web3 font (Sora)
const sora = Sora({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-sora',
  weight: ['400', '600', '700'],
  adjustFontFallback: false,
});

// Monospace for technical elements
const ibmPlexMono = IBM_Plex_Mono({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-mono',
  weight: ['400', '600'],
});
 const metadata = {
  viewport: {
    width: 'device-width',
    initialScale: 1,
    maximumScale: 1,
    userScalable: false,
  }
}
export default function RootLayout({ children }) {
  return (
  <html lang="en" className={`${sora.variable} ${ibmPlexMono.variable} scroll-smooth`}  suppressHydrationWarning>
    <TelegramProvider>
<body className="touch-pan-y select-none min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 font-sans antialiased">
    {children}
      </body>
      </TelegramProvider>
    </html>
    );
}