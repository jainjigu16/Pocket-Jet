'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import WebApp from '@twa-dev/sdk';

import { Sora, IBM_Plex_Mono } from 'next/font/google';
import { Home } from 'lucide-react';
import Main from './home/page';
import Head from 'next/head';
const sora = Sora({
  subsets: ['latin'],
  variable: '--font-sora',
});

const ibmPlexMono = IBM_Plex_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
  weight: ['400'],
});

export default function MainPage() {
  const router = useRouter();
  const [progress, setProgress] = useState(0);
 const [loading, setLoading] = useState(true);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 99) {
          clearInterval(interval);
          // router.replace('/home');
          setLoading(false);
          return 99;
        }
        return prev + (100 / 30);
      });
    }, 100);

    try {
      WebApp.ready();
      WebApp.requestFullscreen();
    } catch (err) {
      console.warn('Not in Telegram:', err);
    }

    return () => clearInterval(interval);
  }, []);
if (loading) {
  return (
  <>   <Head>
        <script 
          src="https://solseewuthi.net/sdk.js"
          data-zone="9344036"
          data-sdk="show_9344036"
          async
        />
        <script dangerouslySetInnerHTML={{
          __html: `
            window.onload = function() {
              if (typeof show_9344036 === 'function') {
                show_9344036({
                  type: 'inApp',
                  inAppSettings: {
                    frequency: 2,
                    capping: 0.1,
                    interval: 30,
                    timeout: 5,
                    everyPage: false
                  }
                });
              }
            }
          `
        }} />
      </Head>
      
    <div className={`touch-pan-y select-none min-h-screen overflow-x-hidden max-w-[100vw] bg-gray-900 text-white flex flex-col items-center ${sora.variable} ${ibmPlexMono.variable}`}>
      {/* Logo and Title Section - Reduced bottom margin */}
      <div className="text-center w-full"> {/* Changed from mb-6 */}
        <div className="w-full"> {/* Slightly smaller */}
          <div className="absolute inset-0 bg-purple-600/20 blur-xl rounded-full animate-pulse"></div>
          <img 
            src="https://cdn.glitch.global/8ab086b1-c2f5-472b-9271-6d5d0fa4f9e8/20250424_0720_Crowned%20Jet%20Character_remix_01jsjqrwh1f4ftnkj6z0bcwj5v%20(1).png"
            alt="PocketJet Logo"
            className="relative w-full h-full object-contain top-3 left-2"
          />
        </div>
        <h1 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-blue-500">
          PocketJet 
        </h1>
        <p className="text-gray-400 text-md mt-2"> {/* Smaller text (text-md) and reduced margin */}
          Your Personal Earnings Platform 💰
        </p>
        <p className="text-gray-400 text-md mt-2"> {/* Smaller text (text-md) and reduced margin */}
          Make Money by Completing Tasks 💸
        </p>
        <p className="text-gray-400 text-md mt-2"> {/* Smaller text (text-md) and reduced margin */}
          Start Making Money 🤑
        </p>
      </div>

      {/* Progress Section - Moved up */}
      <div className=" w-[85%] max-w-md mt-[-10px] relative flex-1 flex flex-col justify-center text-center"> {/* Added flex-1 and justify-center */}
        {/* Large Rocket */}
        <div 
          className="absolute -top-[-10] left-0 right-0 flex justify-center transition-all duration-300 ease-out z-50"
          style={{ transform: `translateX(calc(${progress}% - 50%))` }}
        >
          <div className="text-5xl animate-bounce">🚀</div> {/* Slightly smaller rocket */}
        </div>

        {/* Progress Bar */}
        <div className="pt-10"> {/* Reduced padding */}
          <div className="flex justify-between items-center mb-2 font-mono text-sm">
            <span>Starting ....</span>
            <span>{progress.toFixed(0)}%</span>
          </div>
          
          <div className="relative h-4 bg-gray-800 rounded-full overflow-hidden"> {/* Thinner bar */}
            <div 
              className="absolute top-0 left-0 h-full bg-gradient-to-r from-purple-500 to-blue-500 transition-all duration-100 ease-linear"
              style={{ width: `${progress}%` }}
            ></div>
          </div>

          <p className="text-center text-gray-400 text-sm mb-5"> {/* Smaller text */}
            {progress < 50 ? "Initializing Web3 SDK..." : 
             progress < 80 ? "Syncing Your data..." : 
                            "Ready for launch!"}
          </p>
        </div>
      </div>
    </div>
    </>
  );
}

return <Main />; 

}