'use client';
import { useEffect, useState } from 'react';
import { db } from '@/firebase/firebaseConfig';
import { collection, query, where, getDocs, doc, getDoc } from 'firebase/firestore';
import { Users, Trophy, Zap, ChevronRight, Check, User, Gift } from 'lucide-react';
import { toast, Toaster } from 'react-hot-toast';
import BottomNav from '@/components/BottomNav';
import { useTelegramUser } from '../../components/Taps';

export default function TeamPage() {
  const { user } = useTelegramUser();
  const [team, setTeam] = useState([]);
  const [stats, setStats] = useState({
    totalMembers: 0,
    activeThisWeek: 0,
    teamProgress: 0,
    airdropUnlocked: false
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadTeamData = async () => {
      if (!user?.uid) return; // Changed from user?.id to user?.uid to match your context

      try {
        // 1. First get all referrals where current user is referrer
        const referralsQuery = query(
          collection(db, 'referrals'),
          where('referrerId', '==', user.uid)
        );
        const referralsSnapshot = await getDocs(referralsQuery);

        // 2. Get details for each referred user
        const teamMembers = await Promise.all(
          referralsSnapshot.docs.map(async referralDoc => {
            const referralData = referralDoc.data();
            
            // Get user details from users collection
            const userDoc = await getDoc(doc(db, 'users', referralData.refereeId));
            const userData = userDoc.data();
            
            // Check if user has been active (example: has coins balance)
            const isActive = userData?.coins > 0;
            
            return {
              id: referralData.refereeId,
              name: userData?.first_name || 'Idk 😋',
              username: userData?.username || '',
              joinDate: referralData.createdAt?.toDate() || new Date(),
              level: 1,
              hasActive: isActive
            };
          })
        );

        // 3. Calculate statistics
        const totalMembers = teamMembers.length;
        const activeThisWeek = teamMembers.filter(m => m.hasActive).length;
        const teamProgress = Math.min(100, (totalMembers / 100) * 100);
        const airdropUnlocked = totalMembers >= 100;

        setTeam(teamMembers);
        setStats({
          totalMembers,
          activeThisWeek,
          teamProgress,
          airdropUnlocked
        });

        // 4. Check for airdrop eligibility if not already unlocked
        if (totalMembers >= 100 && !user.airdropReceived) {
          // Update user document to mark airdrop as received
          await updateDoc(doc(db, 'users', user.uid), {
            airdropReceived: true,
            coins: increment(100),
            lastUpdated: serverTimestamp()
          });
          toast.success('🎉 You received 1200 coins airdrop!');
        }

      } catch (error) {
        console.error('Error loading team data:', error);
        toast.error('Failed to load team data');
      } finally {
        setLoading(false);
      }
    };

    loadTeamData();
  }, [user?.uid, user?.airdropReceived]); // Added user.airdropReceived to dependencies

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-950 text-white p-4 flex items-center justify-center">
        <div className="text-center]">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500 mx-auto mb-4"></div>
          <p>Loading your team...</p>
        </div>
      </div>
    );
  }
  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col">
    {/* Main scrollable content */}
    <div className="flex-1 overflow-y-auto p-4 pb-24 mt-[15%]"> {/* Added pb-24 for bottom nav spacing */}
      {/* Team Header */}
      <div className="bg-gradient-to-r from-purple-900 to-blue-900 rounded-2xl p-6 mb-6">
        <h1 className="text-2xl font-bold flex items-center gap-2 mb-2">
          <Users size={24} /> Your Referral Team ✨
        </h1>
        <p className="text-gray-300">Build your team and earn rewards together</p>
        <p className="text-gray-300">Invite And collect 10 coin your Every Referral</p>
      </div>

      {/* Team Stats */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-gray-800 rounded-xl p-4 border border-gray-700">
          <div className="flex items-center gap-2 text-gray-400">
            <Users size={16} />
            <p className="text-sm">Team Size</p>
          </div>
          <p className="text-xl font-bold text-white mt-1">
            {stats.totalMembers}/100
          </p>
        </div>
        <div className="bg-gray-800 rounded-xl p-4 border border-gray-700">
          <div className="flex items-center gap-2 text-gray-400">
            <Zap size={16} />
            <p className="text-sm">Active This Week</p>
          </div>
          <p className="text-xl font-bold text-green-400 mt-1">
            {stats.activeThisWeek}
          </p>
        </div>
      </div>

      {/* Team Progress */}
      <div className="bg-gray-800 rounded-xl p-4 border border-gray-700 mb-6">
        <div className="flex justify-between items-center mb-2">
          <h3 className="font-bold flex items-center gap-2">
            <Trophy size={18} /> Team Goal
          </h3>
          <span className="text-sm text-gray-400">
            {stats.teamProgress.toFixed(0)}%
          </span>
        </div>
        <div className="w-full bg-gray-700 rounded-full h-3">
          <div 
            className="bg-gradient-to-r from-blue-500 to-purple-600 h-3 rounded-full" 
            style={{ width: `${stats.teamProgress}%` }}
          ></div>
        </div>
        <p className="text-sm text-center mt-2 text-gray-400">
          {100 - stats.totalMembers} more to unlock airdrop
        </p>
      </div>

      {/* Airdrop Reward */}
      <div className={`rounded-xl p-4 mb-6 ${
        stats.airdropUnlocked 
          ? 'bg-gradient-to-r from-green-900 to-emerald-800 border border-green-600'
          : 'bg-gray-800 border border-gray-700'
      }`}>
        <div className="flex items-start gap-3">
          <div className={`p-2 rounded-full ${
            stats.airdropUnlocked ? 'bg-green-600' : 'bg-gray-700'
          }`}>
            <Gift size={20} className={stats.airdropUnlocked ? 'text-white' : 'text-gray-400'} />
          </div>
          <div>
            <h3 className="font-bold flex items-center gap-2">
              Team Airdrop Reward
              {stats.airdropUnlocked && (
                <span className="text-xs bg-green-600 text-white px-2 py-1 rounded-full">
                  Unlocked!
                </span>
              )}
            </h3>
            <p className="text-sm mt-1">
              {stats.airdropUnlocked
                ? 'You qualified for 1200 coins airdrop next week!'
                : 'Refer 50 friends to unlock 1200 coins airdrop'
              }
            </p>
            {stats.airdropUnlocked && (
              <p className="text-xs text-green-300 mt-2">
                Airdrop will be distributed on Monday
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Team Members List */}
      <div className="mb-6">
        <h3 className="font-bold text-lg mb-3 flex items-center gap-2">
          <User size={18} /> Your Direct Team ({team.length})
        </h3>
        {team.length === 0 ? (
          <div className="text-center py-6 bg-gray-800 rounded-xl border border-gray-700">
            <p className="text-gray-400 mb-3">No team members yet</p>
            <button className="bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-lg">
              Invite Friends
            </button>
          </div>
        ) : (
          <div className="space-y-3 max-h-96 overflow-y-auto"> {/* Added max height and scroll */}
            {team.map(member => (
              <div key={member.id} className="flex items-center justify-between p-3 bg-gray-800 rounded-lg border border-gray-700">
                <div className="flex items-center gap-3">
                  <div className="bg-gray-700 p-2 rounded-full">
                    <User size={16} />
                  </div>
                  <div>
                    <p className="font-medium">
                      {member.name}
                      {member.username && (
                        <span className="text-gray-400 ml-2">@{member.username}</span>
                      )}
                    </p>
                    <p className="text-xs text-gray-400">
                      Joined: {member.joinDate.toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    member.hasActive ? 'bg-green-900 text-green-400' : 'bg-gray-700 text-gray-400'
                  }`}>
                    {member.hasActive ? 'Active' : 'Inactive'}
                  </span>
                  <ChevronRight size={16} className="text-gray-400" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Team Tasks */}
      <div className="bg-gray-800 rounded-xl p-4 border border-gray-700 mb-6">
        <h3 className="font-bold text-lg mb-3 flex items-center gap-2">
          <Check size={18} /> Team Tasks
        </h3>
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <div className={`mt-1 flex-shrink-0 ${
              stats.totalMembers >= 5 ? 'text-green-400' : 'text-gray-500'
            }`}>
              {stats.totalMembers >= 5 ? (
                <Check size={18} className="bg-green-900 rounded-full p-0.5" />
              ) : (
                <div className="w-4 h-4 border-2 border-gray-500 rounded-full"></div>
              )}
            </div>
            <div>
              <p className="font-medium">Refer 5 friends</p>
              <p className="text-sm text-gray-400">
                {stats.totalMembers >= 5 ? 'Completed!' : `${5 - stats.totalMembers} more to go`}
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className={`mt-1 flex-shrink-0 ${
              stats.totalMembers >= 20 ? 'text-green-400' : 'text-gray-500'
            }`}>
              {stats.totalMembers >= 20 ? (
                <Check size={18} className="bg-green-900 rounded-full p-0.5" />
              ) : (
                <div className="w-4 h-4 border-2 border-gray-500 rounded-full"></div>
              )}
            </div>
            <div>
              <p className="font-medium">Build team of 20</p>
              <p className="text-sm text-gray-400">
                Reward: 200 coins bonus
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className={`mt-1 flex-shrink-0 ${
              stats.airdropUnlocked ? 'text-green-400' : 'text-gray-500'
            }`}>
              {stats.airdropUnlocked ? (
                <Check size={18} className="bg-green-900 rounded-full p-0.5" />
              ) : (
                <div className="w-4 h-4 border-2 border-gray-500 rounded-full"></div>
              )}
            </div>
            <div>
              <p className="font-medium">Team of 100 members</p>
              <p className="text-sm text-gray-400">
                Reward: 1200 coins airdrop
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>

    {/* Bottom Navigation */}
    <div className="fixed bottom-0 left-0 right-0">
      <BottomNav />
    </div>

    <Toaster position="top-center" reverseOrder={false} />
  </div>
  );
}
