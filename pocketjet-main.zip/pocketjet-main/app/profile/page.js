'use client';
import ShareReferral from '@/components/His';
import SupportAndPrivacy from '@/components/SupportAndPolicy';
import { useEffect, useState } from 'react';
import { db } from '@/firebase/firebaseConfig';
import { writeBatch, doc, getDoc, updateDoc, collection, addDoc, query, where, getDocs,serverTimestamp,increment } from 'firebase/firestore';
import { Wallet, Coins, History, User, Copy } from 'lucide-react';
import { toast,Toaster } from 'react-hot-toast';
import BottomNav from '@/components/BottomNav';
export default function ProfilePage() {
  const [userData, setUserData] = useState({
    coins: 0,
    username: '',
    first_name: '',
    bank: '',
    accountNumber: '',
    ifsc: '',
    accountHolderName: '',
    referralCode: '',
    referredBy: ''
  });
  const [referralFriends, setReferralFriends] = useState([]);
  const [totalEarnings, setTotalEarnings] = useState(0);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [showBankModal, setShowBankModal] = useState(false);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [withdrawalHistory, setWithdrawalHistory] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

 const fetchWithdrawalHistory = async (uid) => {
    try {
      const q = query(collection(db, 'withdrawals'), where('userId', '==', uid));
      const querySnapshot = await getDocs(q);
      const history = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt.toDate()
      }));
      setWithdrawalHistory(history);
    } catch (error) {
      console.error('Error fetching withdrawal history:', error);
    }
  };
  // Initialize user data
  useEffect(() => {
    const loadData = async () => {
      try {
        const tgUser = window?.Telegram?.WebApp?.initDataUnsafe?.user;
        if (!tgUser?.id) {
          toast.error('Telegram user not found');
          setIsLoading(false);
          return;
        }

       const uid = tgUser.id.toString();
    
        // Load user data
        const userDoc = await getDoc(doc(db, 'users', uid));
        if (!userDoc.exists()) {
          toast.error('Please Open Again App');
          setIsLoading(false);
          return;
        }

        const userData = userDoc.data();
        let referralCode = userData.referralCode;
        
        // Generate referral code if missing
        if (!referralCode) {
          referralCode = generateReferralCode();
          await updateDoc(doc(db, 'users', uid), { referralCode });
        }

        setUserData({
          coins: userData.coins || 0,
          username: userData.username || tgUser.username || '',
          first_name: userData.first_name || tgUser.first_name || '',
          bank: userData.bank || '',
          accountNumber: userData.accountNumber || '',
          ifsc: userData.ifsc || '',
          accountHolderName: userData.accountHolderName || '',
          referralCode,
          referredBy: userData.referredBy || ''
        });

        const urlParams = new URLSearchParams(window.location.search);
        const refCode = urlParams.get('ref');
        if (refCode && refCode !== referralCode && !userData.referredBy) {
          await handleReferral(uid, refCode);
        }
        const loadReferralFriendsAndEarnings = async (uid) => {
          try {
            // Load referrals
            const referralsQuery = query(
              collection(db, 'referrals'),
              where('referrerId', '==', uid)
            );
            const referralsSnapshot = await getDocs(referralsQuery);
            
            // Calculate total earnings (100 coins per referral)
            setTotalEarnings(referralsSnapshot.size * 100);
        
            // Get details of referred users
            const friends = await Promise.all(
              referralsSnapshot.docs.map(async doc => {
                const referralData = doc.data();
                const userDoc = await getDoc(doc(db, 'users', referralData.refereeId));
                return {
                  id: referralData.refereeId,
                  username: userDoc.data()?.username || 'Unknown',
                  date: referralData.createdAt?.toDate() || new Date()
                };
              })
            );
            
            setReferralFriends(friends);
          } catch (error) {
            console.error('Error loading referral friends:', error);
            toast.error('Failed to load referral data');
          }
        };
      } catch (error) {
        console.error('Failed to load data:', error);
        toast.error('Failed to load user data');
      } finally {
        setIsLoading(false);
      }
    };

  
 const tgUser = window?.Telegram?.WebApp?.initDataUnsafe?.user;
    if (tgUser?.id) {
        fetchWithdrawalHistory(tgUser.id);
        // loadReferralFriendsAndEarnings(tgUser.id);
    }
    loadData();
  }, []);

  const generateReferralCode = () => {
    return Math.random().toString(36).substring(2, 10).toUpperCase();
  };

  const handleReferral = async (userId, refCode) => {
    try {
      const referrerQuery = query(
        collection(db, 'users'),
        where('referralCode', '==', refCode)
      );
      const referrerSnapshot = await getDocs(referrerQuery);
      
      if (!referrerSnapshot.empty) {
        const referrerId = referrerSnapshot.docs[0].id;
        
        await updateDoc(doc(db, 'users', userId), {
          referredBy: refCode
        });

        await addDoc(collection(db, 'referrals'), {
          referrerId,
          refereeId: userId,
          createdAt: new Date(),
          rewardGiven: false
        });

        toast.success('Referral applied successfully!');
      }
    } catch (error) {
      console.error('Referral error:', error);
    }
  };

  const handleBankDetailChange = (field, value) => {
    setUserData(prev => ({
      ...prev,
      [field]: typeof value === 'string' ? value.trim() : value
    }));
  };

const saveBankDetails = async () => {
  if (!/^[a-zA-Z ]+$/.test(userData.accountHolderName.trim())) {
    toast.error('Please enter a valid account holder name');
    return;
  }

  if (!userData.bank.trim()) {
    toast.error('Please enter your bank name');
    return;
  }

  if (!/^\d{11,16}$/.test(userData.accountNumber)) {
    toast.error('Account number must be 11-16 digits');
    return;
  }

  if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(userData.ifsc)) {
    toast.error('Please enter a valid 11-character IFSC code');
    return;
  }
 
    try {
      setIsSaving(true);
      const uid = String(window?.Telegram?.WebApp?.initDataUnsafe?.user?.id); // convert to string
      if (!uid) throw new Error('User not authenticated');
  
      await updateDoc(doc(db, 'users', uid), {
        bank: userData.bank,
        accountNumber: userData.accountNumber,
        ifsc: userData.ifsc,
        accountHolderName: userData.accountHolderName
      });
  
      toast.success('Bank details saved successfully!');
      setShowBankModal(false);
    } catch (error) {
      console.error('Failed to save bank details:', error);
      toast.error('Failed to save bank details');
    } finally {
      setIsSaving(false);
    }
  };
  
  const handleWithdraw = async () => {
    if (!withdrawAmount || withdrawAmount < 300) {
      toast.error('Minimum withdrawal is 300 coins');
      return;
    }

    if (withdrawAmount > userData.coins) {
      toast.error('Insufficient coins');
      return;
    }

    if (!userData.accountNumber || !userData.ifsc || !userData.accountHolderName) {
      toast.error('Please complete your bank details first');
      setShowBankModal(true);
      return;
    }

    try {
      setIsSaving(true);
      const uid = window?.Telegram?.WebApp?.initDataUnsafe?.user?.id;
      if (!uid) throw new Error('User not authenticated');

      await addDoc(collection(db, 'withdrawals'), {
        userId: uid,
        amount: parseInt(withdrawAmount),
        bankDetails: {
          bank: userData.bank,
          accountNumber: userData.accountNumber,
          ifsc: userData.ifsc,
          holder: userData.accountHolderName
        },
        status: 'pending',
        createdAt: new Date()
      });
      const uiid = String(window?.Telegram?.WebApp?.initDataUnsafe?.user?.id); // convert to string
      if (!uiid) throw new Error('User not authenticated');
      await updateDoc(doc(db, 'users', uiid), {
        coins: userData.coins - parseInt(withdrawAmount)
      });

      setUserData(prev => ({ ...prev, coins: prev.coins - parseInt(withdrawAmount) }));
      setWithdrawAmount('');
      setShowWithdrawModal(false);
      toast.success('Withdrawal request submitted!');

      // Refresh history
      const withdrawalsQuery = query(
        collection(db, 'withdrawals'),
        where('userId', '==', uid)
      );
      const withdrawalsSnapshot = await getDocs(withdrawalsQuery);
      const history = withdrawalsSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate() || new Date()
      }));
      setWithdrawalHistory(history);
    } catch (error) {
      console.error('Withdrawal failed:', error);
      toast.error('Withdrawal failed');
    } finally {
      setIsSaving(false);
    }
  };
  
  const totalWithdrawn = withdrawalHistory.reduce(
    (sum, withdrawal) => sum + (withdrawal.status === 'approved' ? withdrawal.amount : 0),
    0
  );

  const copyReferralLink = () => {
    const link = `https://t.me/pocketjetbot/app?startapp=${userData.referralCode}`;
    navigator.clipboard.writeText(link);
    toast.success('Referral link copied!');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500 mx-auto mb-4"></div>
          <p>Loading your profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6 overflow-scroll align-middle">
       <SupportAndPrivacy />
<Toaster 
            position="bottom-center"
            toastOptions={{
              style: {
                background: '#363636',
                color: '#fff',
                alignItems: 'center',
                justifyContent: 'center',
                marginTop: '20px'
              },
            }}
          /> 
     <div className="flex-1 overflow-y-auto pb-24 mt-[15%] align-middle">
      <div className="bg-gray-800 rounded-2xl p-6 mb-6 border border-gray-700">
        <div className="flex items-center">
          <div className="bg-gray-700 p-0 border-2 border-purple-600/80 rounded-full mr-4">
            {/* <User size={24} className="text-gray-300" /> */}
            <img
            src={window?.Telegram?.WebApp?.initDataUnsafe?.user?.photo_url}
            onError={(e) => e.target.src = '/rocket.png'}
            alt="profile"
            className="w-15 h-15 rounded-full object-cover" />
     
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">{userData.first_name}</h1>
            <p className="text-gray-400">@{userData.username}</p>
          </div>
        </div>
        
        <div className="mt-6 bg-gray-800 rounded-xl p-4 flex justify-between items-center border border-gray-700">
          <div>
            <p className="text-sm text-gray-400">Your Balance <span className='text-yellow-400'>90 = $1.0💲</span></p>
            <h2 className="text-3xl font-bold text-white">{userData.coins}</h2>
          </div>
          <div className="bg-gray-700 p-3 rounded-full">
            <Coins className="text-yellow-400" size={24} />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4 mt-5">
        <div className="bg-gray-800 rounded-xl p-4 border border-gray-700">
          <p className="text-sm text-gray-400">Total Earned</p>
          <p className="text-xl font-bold text-green-400">{totalEarnings} coins</p>
        </div>
        <div className="bg-gray-800 rounded-xl p-4 border border-gray-700">
          <p className="text-sm text-gray-400">Total Withdrawn</p>
          <p className="text-xl font-bold text-yellow-400">{totalWithdrawn} coins</p>
        </div>
      </div>
      </div>

      {/* Referral Section */}
      <div className="bg-gray-800 rounded-2xl p-5 mb-6 border border-gray-700">
        <h3 className="font-bold text-white mb-2">Your Referral Link</h3>
        <div className="flex items-center bg-gray-900 rounded-lg p-3 border border-gray-700">
          <span className="font-mono text-gray-300 flex-1 truncate">
            https://t.me/pocketjetbot/app?startapp={userData.referralCode}
          </span>
          <button 
            onClick={copyReferralLink}
            className="bg-gray-700 hover:bg-gray-600 p-2 rounded-lg transition"
            disabled={isSaving}
          >
            <Copy size={16} className="text-gray-300" />
          </button>
        </div>
        <div className='flex flex-col-reverse justify-between m-2 '>
        <ShareReferral referralCode={userData.referralCode}/>
        </div>
        <p className="text-sm mt-2 text-gray-400">
          Earn 10+ coins for each friend who joins using your link!
        </p>

        {/* Referral Friends List */}
        {referralFriends.length > 0 && (
          <div className="mt-4">
            <h4 className="font-bold text-white mb-2">Friends Joined ({referralFriends.length})</h4>
            <div className="max-h-40 overflow-y-auto">
              {referralFriends.map(friend => (
                <div key={friend.id} className="flex justify-between items-center py-2 border-b border-gray-700">
                  <span className="text-gray-300">@{friend.username}</span>
                  <span className="text-xs text-gray-500">
                    {friend.date.toLocaleDateString()}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <button 
          onClick={() => setShowBankModal(true)}
          className="bg-gray-800 hover:bg-gray-700 p-4 rounded-xl flex flex-col items-center border border-gray-700 transition"
          disabled={isSaving}
        >
          <Wallet className="mb-2 text-blue-400" size={20} />
          <span className="text-white">{userData.bank ? 'Update Bank' : 'Add Bank'}</span>
        </button>
        <button 
          onClick={() => setShowWithdrawModal(true)}
          className="bg-gray-800 hover:bg-gray-700 p-4 rounded-xl flex flex-col items-center border border-gray-700 transition"
          disabled={isSaving || userData.coins < 300}
        >
          <Coins className="mb-2 text-yellow-400" size={20} />
          <span className="text-white">Withdraw</span>
        </button>
      </div>

      {/* History Button */}
      <button
        onClick={() => setShowHistoryModal(true)}
        className="w-full bg-gray-800 hover:bg-gray-700 p-4 rounded-xl mb-10 flex items-center justify-center gap-2 border border-gray-700 transition"
        disabled={isSaving}
      >
        <History size={20} className="text-gray-300" />
        <span className="text-white">View History</span>
      </button>
     
      {showBankModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
  <div className="bg-gray-900 rounded-2xl p-6 w-full max-w-md border border-gray-700">
    <h2 className="text-xl font-bold text-white mb-4">Bank Details</h2>
    
    <div className="space-y-3 mb-4">
      <div>
        <label className="block text-sm text-gray-400 mb-1">Account Holder Name</label>
        <input
          className="w-full bg-gray-800 text-white border border-gray-700 rounded-lg p-3"
          value={userData.accountHolderName}
          onChange={(e) => handleBankDetailChange('accountHolderName', e.target.value)}
          placeholder="Full name as in bank"
          disabled={isSaving}
          pattern="[a-zA-Z ]+"
          title="Only alphabets and spaces allowed"
          required
        />
      </div>
      <div>
        <label className="block text-sm text-gray-400 mb-1">Bank Name</label>
        <input
          className="w-full bg-gray-800 text-white border border-gray-700 rounded-lg p-3"
          value={userData.bank}
          onChange={(e) => handleBankDetailChange('bank', e.target.value)}
          placeholder="Bank name"
          disabled={isSaving}
          required
        />
      </div>
      <div>
        <label className="block text-sm text-gray-400 mb-1">Account Number</label>
        <input
          className="w-full bg-gray-800 text-white border border-gray-700 rounded-lg p-3"
          value={userData.accountNumber}
          onChange={(e) => handleBankDetailChange('accountNumber', e.target.value.replace(/\D/g, ''))}
          placeholder="Account Number"
          disabled={isSaving}
          minLength="11"
          maxLength="16"
          pattern="[0-9]{11,16}"
          title="11-16 digit account number"
          required
        />
      </div>
      <div>
        <label className="block text-sm text-gray-400 mb-1">IFSC Code</label>
        <input
          className="w-full bg-gray-800 text-white border border-gray-700 rounded-lg p-3"
          value={userData.ifsc}
          onChange={(e) => {
            const value = e.target.value.toUpperCase();
            if (/^[A-Z]{4}0[A-Z0-9]{5}$/.test(value) || value.length <= 11) {
              handleBankDetailChange('ifsc', value);
            }
          }}
          placeholder="11 character IFSC (e.g. SBIN0001234)"
          disabled={isSaving}
          pattern="[A-Z]{4}0[A-Z0-9]{6}"
          title="4 letters + 0 + 5 letters/numbers (e.g. SBIN0001234)"
          maxLength="11"
          required
        />
      </div>
    </div>

    {/* UPI/Crypto Note */}
    <div className="bg-blue-900/20 border border-blue-700 rounded-lg p-3 mb-4">
      <p className="text-sm text-blue-300">
        <span className="font-bold">Note:</span> For UPI or cryptocurrency withdrawals, 
        please contact our <button 
          onClick={() => {
            setShowBankModal(false);
            // Open support modal or link here
            window.open('https://t.me/pocketjet_official', '_blank');
          }}
          className="text-blue-400 hover:underline"
        >
          customer support 🤝
        </button>.
      </p>
    </div>

    <div className="flex gap-3">
      <button
        className="flex-1 bg-gray-700 hover:bg-gray-600 text-white py-3 rounded-lg transition"
        onClick={() => setShowBankModal(false)}
        disabled={isSaving}
      >
        Cancel
      </button>
      <button
        className="flex-1 bg-blue-600 hover:bg-blue-500 text-white py-3 rounded-lg transition font-medium"
        onClick={saveBankDetails}
        disabled={isSaving}
      >
        {isSaving ? 'Saving...' : 'Save'}
      </button>
    </div>
  </div>
</div>
      )}

      {/* Withdraw Modal */}
      {showWithdrawModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-900 rounded-2xl p-6 w-full max-w-md border border-gray-700">
            <h2 className="text-xl font-bold text-white mb-4">Withdraw Coins</h2>
            
            <div className="mb-6">
              <label className="block text-sm text-gray-400 mb-1">Amount (min 300)</label>
              <input
                type="number"
                className="w-full bg-gray-800 text-white border border-gray-700 rounded-lg p-3"
                value={withdrawAmount}
                onChange={(e) => setWithdrawAmount(e.target.value)}
                min="300"
                max={userData.coins}
                placeholder="Enter amount"
                disabled={isSaving}
              />
              <p className="text-xs text-gray-500 mt-1">Available: {userData.coins} coins</p>
            </div>

            <div className="bg-gray-800 rounded-lg p-4 mb-6 border border-gray-700">
              <h3 className="font-bold text-white mb-2">Bank Details</h3>
              {userData.bank ? (
                <>
                  <p className="text-gray-300">{userData.accountHolderName}</p>
                  <p className="text-gray-300">{userData.bank} - ●●●●{userData.accountNumber?.slice(-4)}</p>
                  <p className="text-gray-300">IFSC: {userData.ifsc}</p>
                </>
              ) : (
                <p className="text-gray-500">No bank details added</p>
              )}
            </div>

            <div className="flex gap-3">
              <button
                className="flex-1 bg-gray-700 hover:bg-gray-600 text-white py-3 rounded-lg transition"
                onClick={() => setShowWithdrawModal(false)}
                disabled={isSaving}
              >
                Cancel
              </button>
              <button
                className="flex-1 bg-yellow-600 hover:bg-yellow-500 text-white py-3 rounded-lg transition font-medium"
                onClick={handleWithdraw}
                disabled={isSaving || !userData.bank}
              >
                {isSaving ? 'Processing...' : 'Confirm'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* History Modal */}
      {showHistoryModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-900 rounded-2xl p-6 w-full max-w-md border border-gray-700 max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-white">Withdrawal History</h2>
              <button 
                onClick={() => setShowHistoryModal(false)}
                className="text-gray-400 hover:text-white"
                disabled={isSaving}
              >
                ✕
              </button>
            </div>
            
            <div className="space-y-3">
              {withdrawalHistory.length === 0 ? (
              
                <p className="text-gray-500 text-center py-4">No withdrawal history yet</p>
              
                
              ) : (
                withdrawalHistory.map(item => (
                  <div key={item.id} className="bg-gray-800 p-4 rounded-lg border border-gray-700">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="font-bold text-white">{item.amount} coins</span>
                        <p className="text-sm text-gray-400 mt-1">
                          {item.bankDetails.bank} - ●●●●{item.bankDetails.accountNumber?.slice(-4)}
                        </p>
                      </div>
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        item.status === 'approved' ? 'bg-green-900 text-green-400' :
                        item.status === 'rejected' ? 'bg-red-900 text-red-400' :
                        'bg-yellow-900 text-yellow-400'
                      }`}>
                        {item.status}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      {item.createdAt.toLocaleString()}
                    </p>
                    {item.adminNote && (
                      <p className="text-xs mt-2 text-gray-400">
                        <span className="text-gray-500">Note:</span> {item.adminNote}
                      </p>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
      </div>
    <div className="fixed bottom-0 left-0 right-0">
      <BottomNav />
    </div>
    </div>
  );
}