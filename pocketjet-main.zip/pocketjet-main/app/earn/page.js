'use client';
import { useTelegramUser } from '@/components/Taps';
import { Youtube, Send, Instagram, MessageSquare, HelpCircle } from 'lucide-react';
import { useState,useEffect } from 'react';
import { toast } from 'react-hot-toast';
import BottomNav from '@/components/BottomNav';
import { Suspense } from 'react';
import PartnersModal from '@/components/Partner';
export default function AirdropPage() {

  const [claimed, setClaimed] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleClaim = () => {
    setLoading(true);
    setTimeout(() => {
      setClaimed(true);
      setLoading(false);
      toast.success('Airdrop claimed! 1200 coins added to your balance');
    }, 1500);
  };

  const tgUser = window?.Telegram?.WebApp?.initDataUnsafe?.user;
        if (!tgUser?.id) {
          return;
        }
const uid = tgUser.id.toString();

  return (
 <div className="min-h-screen  bg-gray-900 text-white p-4 flex flex-col">
  <div className='flex-1 overflow-y-auto p-4 pb-24 mt-[15%]'>
<div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl p-6 mb-8 text-center">
        <h1 className="text-3xl font-bold mb-2">🚀 Mega Airdrop</h1>
        <p className="text-lg mb-4">Limited Time Offer!</p>   
      </div>
      <div className="relative border border-white rounded-2xl px-6 py-4 mt-6 border-t-2">
  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-gray-900 px-3 text-white text-sm font-semibold">
    Our Social Media
  </div>
  <div className="flex justify-center gap-4 pt-3 pb-3">
    <a 
      href="https://www.youtube.com/@pocketjet-official"
      rel="noopener noreferrer"
      target="_blank"
      className="bg-red-600 hover:bg-red-700 p-3 rounded-full transition"
    >
      <Youtube size={24} />
    </a>
    <a 
      href="https://t.me/+2SWZt0q3O9A4NWM1" 
      target="_blank"
      className="bg-blue-500 hover:bg-blue-600 p-3 rounded-full transition"
    >
      <Send size={24} />
    </a>
    <a 
      href="https://www.instagram.com/pocketjet_offical"
      rel="noopener noreferrer" 
      target="_blank"
      className="bg-gradient-to-tr from-purple-600 to-pink-600 hover:opacity-90 p-3 rounded-full transition"
    >
      <Instagram size={24} />
    </a>
    <a 
      href="https://whatsapp.com/channel/0029VbAuIHC2kNFwVKsNfK1c" 
      target="_blank"
      className="bg-green-500 hover:bg-green-600 p-3 rounded-full transition"
    >
      <MessageSquare size={24} />
    </a>
    <a 
      href="mailto:di.help@proton.me" 
      target="_blank"
      className="bg-gray-700 hover:bg-gray-600 p-3 rounded-full transition"
    >
      <HelpCircle size={24} />
    </a>
  </div>
</div>

      {/* <div className="grid gap-6 mb-8"> */}
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      <div className="mb-2">
        <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">
          Earn Coins with Our Partners
        </h1>
        <p className="text-gray-400 text-base sm:text-lg max-w-3xl">
      Complete offers from our trusted partners to earn PocketJet coins. 
        </p>
      </div>
      <PartnersModal />
    </div>
      <div className="bg-gray-800 rounded-2xl p-6 mb-5">
        <h2 className="text-2xl font-bold mb-4 text-center">💰 Bonus System</h2>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-gray-700 p-4 rounded-xl">
            <h3 className="font-bold text-yellow-400">Weekly Payment</h3>
            <p className="text-sm">Every Monday</p>
          </div>
          <div className="bg-gray-700 p-4 rounded-xl">
            <h3 className="font-bold text-purple-400">Monthly Bonus</h3>
            <p className="text-sm">Extra 10% rewards</p>
          </div>
          <div className="bg-gray-700 p-4 rounded-xl col-span-2">
            <h3 className="font-bold text-green-400">1200 Coins/Week</h3>
            <p className="text-sm">Consistent earnings</p>
          </div>
        </div>
      </div>
      </div>
       <div className="fixed bottom-0 left-0 right-0">
         <BottomNav />
       </div>
    </div>
  );
}