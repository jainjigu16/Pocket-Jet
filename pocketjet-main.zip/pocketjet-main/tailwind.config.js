// tailwind.config.js
const {heroui} = require("@heroui/react");

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./node_modules/@heroui/theme/dist/components/(button|ripple|spinner).js",
  ],
  theme: {
    extend: {
      touchAction: {
        'pan-y': 'pan-y',
      }
    },
  },
  darkMode: "class",
  plugins: [heroui()],
};